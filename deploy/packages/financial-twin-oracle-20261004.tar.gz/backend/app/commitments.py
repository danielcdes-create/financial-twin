"""User-managed future commitments. A schedule never represents a cash debit."""
import calendar
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from typing import Literal
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field, model_validator


Frequency = Literal["semanal", "mensal", "trimestral", "semestral", "anual"]


class CommitmentIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    kind: Literal["assinatura", "parcelamento"]
    name: str = Field(min_length=1, max_length=160)
    purchase_date: date
    next_due_date: date
    amount: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    frequency: Frequency = "mensal"
    installment_count: int | None = Field(default=None, ge=1, le=600)
    next_installment_number: int | None = Field(default=None, ge=1, le=600)
    payment_method: Literal["cartao", "debito", "pix", "boleto", "paypal", "outro"]
    billing_platform: str | None = Field(default=None, max_length=120)
    card_id: str | None = None
    account_id: str | None = None
    renewal_status: Literal["automatica", "manual", "nao_renovar", "nao_aplicavel"] = "nao_aplicavel"
    remaining_charges: int | None = Field(default=None, ge=0, le=600)
    end_date: date | None = None
    status: Literal["ativo", "pausado", "cancelado", "concluido"] = "ativo"
    category: str | None = Field(default=None, max_length=120)
    notes: str | None = Field(default=None, max_length=1000)
    creation_id: UUID | None = None
    request_id: UUID | None = None
    revision: int | None = Field(default=None, ge=1)

    @model_validator(mode="after")
    def coherent(self):
        if self.kind == "parcelamento":
            if self.installment_count is None or self.next_installment_number is None:
                raise ValueError("Informe o total e o número da próxima parcela.")
            if self.next_installment_number > self.installment_count:
                raise ValueError("A próxima parcela excede o total de parcelas.")
            if self.renewal_status != "nao_aplicavel":
                raise ValueError("Renovação só se aplica a assinaturas.")
        elif self.installment_count is not None or self.next_installment_number is not None:
            raise ValueError("Número de parcelas só se aplica a parcelamentos.")
        if self.kind == "assinatura" and self.renewal_status == "nao_renovar" and self.remaining_charges is None:
            raise ValueError("Informe quantas cobranças restam até o término da assinatura.")
        if self.status == "cancelado" and self.remaining_charges:
            raise ValueError("Um compromisso cancelado não pode ter cobranças restantes. Use ativo e sem renovação se elas ainda serão cobradas.")
        if self.kind == "parcelamento" and self.remaining_charges is not None:
            raise ValueError("Cobranças restantes só se aplicam a assinaturas.")
        if self.next_due_date < self.purchase_date:
            raise ValueError("O próximo compromisso não pode anteceder a compra.")
        if self.end_date and self.end_date < self.purchase_date:
            raise ValueError("A data de término não pode anteceder a contratação.")
        if self.payment_method == "cartao" and not self.card_id:
            raise ValueError("Selecione o cartão usado no pagamento.")
        return self


def advance(day: date, frequency: Frequency, steps: int) -> date:
    if frequency == "semanal":
        return day + timedelta(weeks=steps)
    months = {"mensal": 1, "trimestral": 3, "semestral": 6, "anual": 12}[frequency] * steps
    index = day.year * 12 + day.month - 1 + months
    year, month = divmod(index, 12)
    month += 1
    return date(year, month, min(day.day, calendar.monthrange(year, month)[1]))


def as_date(value: date | datetime | str) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    return date.fromisoformat(value[:10])


def bson_date(value: date | None) -> datetime | None:
    return datetime(value.year, value.month, value.day, tzinfo=timezone.utc) if value else None


def schedule(item: dict, count: int = 12, *, offset: int = 0) -> list[dict]:
    if item.get("status") != "ativo":
        return []
    start = as_date(item["next_due_date"])
    anchor_day=item.get("schedule_anchor_day") or start.day
    anchor_end=item.get("schedule_anchor_end",False)
    def occurrence(offset):
        result=advance(start,item["frequency"],offset)
        if item["frequency"]!="semanal":
            last=calendar.monthrange(result.year,result.month)[1]
            result=result.replace(day=last if anchor_end else min(anchor_day,last))
        return result
    first_number = item.get("next_installment_number") or 1
    total = item.get("installment_count")
    remaining = item.get("remaining_charges") if item.get("renewal_status") == "nao_renovar" else None
    available = count if total is None else min(count, total - first_number + 1 - offset)
    if remaining is not None:
        available = min(available, remaining - offset)
    if item.get("renewal_status") == "manual":
        available = min(available, 1 - offset)
    end = as_date(item["end_date"]) if item.get("end_date") else None
    return [{"due_date": occurrence(offset).isoformat(),
             "amount": float(item["amount"]),
             "installment_number": first_number + offset if total else None,
             "status": "previsto"} for offset in range(offset, offset + max(0, available))
            if (end is None or occurrence(offset) <= end) and (not item.get('future_cutoff') or occurrence(offset) < as_date(item['future_cutoff']))]


def schedule_from(item: dict, start: date, count: int = 600) -> list[dict]:
    """Seek by frequency without consuming the display limit on overdue history."""
    anchor = as_date(item['next_due_date'])
    if item['frequency'] == 'semanal':
        offset = max(0, (start - anchor).days // 7)
    else:
        step = {'mensal': 1, 'trimestral': 3, 'semestral': 6, 'anual': 12}[item['frequency']]
        months = (start.year - anchor.year) * 12 + start.month - anchor.month
        offset = max(0, months // step)
    return [row for row in schedule(item, count + 1, offset=offset) if row['due_date'] >= start.isoformat()][:count]


def stored_document(body: CommitmentIn, existing: dict | None = None) -> dict:
    now = datetime.now(timezone.utc)
    value = body.model_dump(mode="json")
    value.pop('request_id',None)
    value.pop("revision", None)
    value.pop("creation_id", None)
    value["name"] = value["name"].strip()
    value["amount"] = str(body.amount)
    for field in ("purchase_date", "next_due_date", "end_date"):
        value[field] = bson_date(getattr(body, field))
    value.update({"commitment_id": existing["commitment_id"] if existing else str(uuid4()),
                  "created_at": existing["created_at"] if existing else now,
                  "updated_at": now,
                  "source": "mobile_manual",
                  "linked_transactions": existing.get("linked_transactions", []) if existing else []})
    same_schedule=bool(existing and as_date(existing["next_due_date"])==body.next_due_date and existing["frequency"]==body.frequency)
    value["schedule_anchor_day"]=(existing.get("schedule_anchor_day") or as_date(existing["next_due_date"]).day) if same_schedule else body.next_due_date.day
    value["schedule_anchor_end"]=existing.get("schedule_anchor_end",False) if same_schedule else body.next_due_date.day==calendar.monthrange(body.next_due_date.year,body.next_due_date.month)[1]
    value["revision"] = (existing.get("revision") or 1) + 1 if existing else 1
    if body.status=='cancelado':value['cancelled_at']=(existing or {}).get('cancelled_at') or value['updated_at']
    return value


def future_pending_total(item: dict) -> Decimal | None:
    if item.get("status") == "cancelado" and item.get("remaining_charges"):
        return None
    if item.get("status") != "ativo":
        return Decimal("0")
    if item.get("kind") == "assinatura" and item.get("renewal_status") == "automatica" and not item.get("end_date"):
        return None
    return sum((Decimal(str(part["amount"])) for part in schedule(item, 600)), Decimal("0"))
