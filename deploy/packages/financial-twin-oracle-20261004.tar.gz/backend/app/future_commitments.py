"""Future-only corrections: imported originals and actual payments stay intact."""
import copy
import hashlib
from datetime import date, datetime, timezone
from decimal import Decimal
from typing import Literal
from uuid import UUID

from bson import ObjectId, json_util
from bson.decimal128 import Decimal128
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field
from pymongo.errors import DuplicateKeyError
from app.auth import require_session
from app.atomic import mongo_snapshot, mongo_transaction, session_database
from app.commitments import as_date, schedule_from
from app.economic_policy import amount
from app.financial_time import today

Source = Literal['installment', 'obligation', 'managed']
router = APIRouter(prefix='/v1/future-commitments', dependencies=[Depends(require_session)])

def database(request: Request):
    if request.app.state.db is None: raise HTTPException(503, 'Banco indisponível.')
    return request.app.state.db

def digest(value):
    return hashlib.sha256(json_util.dumps(value, sort_keys=True).encode()).hexdigest()

def load(db, source, identity):
    if source == 'managed':
        document = db.commitments.find_one({'commitment_id': identity})
    else:
        if not ObjectId.is_valid(identity): raise HTTPException(404, 'Compromisso não encontrado.')
        document = db['installment_plans' if source == 'installment' else 'obligations'].find_one({'_id': ObjectId(identity)})
    if not document: raise HTTPException(404, 'Compromisso não encontrado.')
    return document

def due(part):
    value = part.get('data_vencimento')
    return as_date(value) if value else None

def unpaid(db, source, document, part, linked=None):
    if source == 'installment':
        return document.get('status') == 'ativo' and part.get('status') == 'projetada' and not part.get('transaction_id') and not part.get('bill_id')
    if document.get('status') != 'futura': return False
    if (amount(document.get('valor_pago')) or Decimal('0')) != 0: return False
    if linked is not None: return document['_id'] not in linked
    return not db.reconciliations.find_one({'$or': [
        {'origem.entity': 'obligations', 'origem.id': document['_id']},
        {'destino.entity': 'obligations', 'destino.id': document['_id']}, {'obligation_id': document['_id']}]})

def editable(db, source, document, part, linked=None):
    if not unpaid(db, source, document, part, linked): return False
    if source == 'installment':
        exact = due(part)
        month = str(part.get('competencia') or '')
        if exact: return exact >= today()
        try: date.fromisoformat(month + '-01')
        except ValueError: return False
        return month >= today().strftime('%Y-%m')
    return bool(due(document) and due(document) >= today())

def obligation_links(db, documents):
    ids = [document['_id'] for document in documents]
    if not ids: return set()
    links = list(db.reconciliations.find({'$or': [
        {'origem.entity': 'obligations', 'origem.id': {'$in': ids}},
        {'destino.entity': 'obligations', 'destino.id': {'$in': ids}}, {'obligation_id': {'$in': ids}}]}).limit(10001))
    if len(links) > 10000: raise HTTPException(409, 'Vínculos demais para conferir com segurança.')
    result = set()
    for link in links:
        if link.get('obligation_id'): result.add(link['obligation_id'])
        for endpoint in (link.get('origem', {}), link.get('destino', {})):
            if endpoint.get('entity') == 'obligations' and endpoint.get('id'): result.add(endpoint['id'])
    return result

def effective_document(db, source, document, override=None, linked=None):
    result = copy.deepcopy(document)
    if override is None: override = db.future_schedule_overrides.find_one({'_id': f'{source}:{document["_id"]}'})
    if not override: return result
    patches = override.get('rows', {})
    original_parts = document.get('installments', []) if source == 'installment' else [document]
    for index, original in enumerate(original_parts, 1):
        patch = patches.get(str(index))
        if not patch: continue
        # A subsequent importer cannot apply a stale correction to a paid/different row.
        if digest(original) != patch['original_token'] or not unpaid(db, source, document, original, linked):
            result['future_correction_needs_review'] = True
            continue
        target = result['installments'][index - 1] if source == 'installment' else result
        if patch['cancelled']:
            target['status'] = 'cancelada'; target['future_excluded'] = True
        else:
            target['valor' if source == 'installment' else 'saldo_aberto'] = Decimal128(patch['amount'])
            if patch['due_date']:
                target['data_vencimento'] = datetime.fromisoformat(patch['due_date']).replace(tzinfo=timezone.utc)
                target['competencia'] = patch['due_date'][:7]
            target['future_edited'] = True
    return result

def effective_documents(db, source, documents):
    documents = list(documents)
    if not documents: return []
    overrides = {item['_id']: item for item in db.future_schedule_overrides.find({'_id': {'$in': [f'{source}:{row["_id"]}' for row in documents]}})}
    linked = obligation_links(db, [row for row in documents if f'{source}:{row["_id"]}' in overrides]) if source == 'obligation' else None
    return [effective_document(db, source, document, overrides.get(f'{source}:{document["_id"]}', {}), linked) for document in documents]

def view(db, source, identity):
    original = load(db, source, identity)
    override = None if source == 'managed' else db.future_schedule_overrides.find_one({'_id': f'{source}:{identity}'})
    token = digest({'original': original, 'override': override, 'civil_day': today().isoformat()})
    if source == 'managed':
        rows = [{'row_id': i, **row, 'editable': True} for i, row in enumerate(schedule_from(original, today(), 600), 1)]
        return {'source': source, 'identity': identity, 'name': original['name'], 'preview_token': token, 'rows': rows,
                'editable_count': sum(row['editable'] for row in rows), 'revision': original.get('revision', 1)}
    current = effective_document(db, source, original, override)
    parts = original.get('installments', []) if source == 'installment' else [original]
    effective_parts = current.get('installments', []) if source == 'installment' else [current]
    rows = []
    for i, (part, actual) in enumerate(zip(parts, effective_parts), 1):
        value = amount(actual.get('valor') if source == 'installment' else actual.get('saldo_aberto'))
        allowed = unpaid(db, source, original, part) and editable(db, source, current, actual) and not actual.get('future_excluded') and value is not None and value > 0
        rows.append({'row_id': i, 'number': part.get('numero') or part.get('parcela_numero'),
                     'due_date': due(actual).isoformat() if due(actual) else None, 'month': actual.get('competencia'),
                     'amount': str(value) if value is not None else None, 'status': actual.get('status'),
                     'editable': allowed, 'excluded': bool(actual.get('future_excluded')),
                     'reason': '' if allowed else 'Histórico, vencida, vinculada a pagamento ou já excluída: preservada.'})
    return {'source': source, 'identity': identity, 'name': current.get('descricao') or f'{current.get("tipo", "Obrigação")} · {current.get("competencia", "")}',
            'preview_token': token, 'rows': rows, 'editable_count': sum(row['editable'] for row in rows),
            'needs_review': bool(current.get('future_correction_needs_review'))}

class FutureChange(BaseModel):
    model_config = ConfigDict(extra='forbid')
    row_id: int = Field(ge=1, le=600)
    amount: Decimal = Field(gt=0, max_digits=12, decimal_places=2)
    due_date: date | None = None
    cancelled: bool = False

class FutureWrite(BaseModel):
    model_config = ConfigDict(extra='forbid')
    request_id: UUID
    preview_token: str = Field(pattern=r'^[a-f0-9]{64}$')
    rows: list[FutureChange] = Field(min_length=1, max_length=600)

class FutureDelete(BaseModel):
    model_config = ConfigDict(extra='forbid')
    request_id: UUID
    preview_token: str = Field(pattern=r'^[a-f0-9]{64}$')

@router.get('/obligations')
def future_obligations(db=Depends(database)):
    with mongo_snapshot(db) as (reading, consistency):
        return {**future_obligations_view(reading), 'read_consistency': consistency}

def future_obligations_view(db):
    candidates = list(db.obligations.find({'status': 'futura'}).sort('data_vencimento', 1).limit(1001))
    if len(candidates) > 1000: raise HTTPException(409, 'Há mais de mil obrigações; restrinja o cadastro antes de gerenciar.')
    items = []
    linked = obligation_links(db, candidates)
    for original, current in zip(candidates, effective_documents(db, 'obligation', candidates)):
        if not unpaid(db, 'obligation', original, original, linked) or not editable(db, 'obligation', current, current, linked): continue
        if current.get('future_excluded'): continue
        items.append({'id': str(original['_id']), 'name': current.get('descricao') or f'{current.get("tipo", "Obrigação")} · {current.get("competencia", "")}',
                      'due_date': due(current).isoformat(), 'amount': str(amount(current.get('saldo_aberto'))), 'needs_review': bool(current.get('future_correction_needs_review'))})
    return {'items': sorted(items, key=lambda item: (item['due_date'], item['id']))}

@router.get('/{source}/{identity}')
def preview(source: Source, identity: str, db=Depends(database)):
    with mongo_snapshot(db) as (reading, consistency): return {**view(reading, source, identity), 'read_consistency': consistency}

def write(db, source, identity, body, deleting=False):
    request_digest = digest({'source': source, 'identity': identity, 'deleting': deleting, 'body': body.model_dump(mode='json')})
    try:
        with mongo_transaction(db) as session:
            writing = session_database(db, session)
            previous = writing.future_commitment_commands.find_one({'_id': str(body.request_id)})
            if previous:
                if previous['request_digest'] != request_digest: raise HTTPException(409, 'Identificador já usado para outra alteração.')
                return {**previous['result'], 'duplicate_request': True}
            reviewed = view(writing, source, identity)
            if reviewed['preview_token'] != body.preview_token: raise HTTPException(409, 'O compromisso mudou. Reabra e confira novamente.')
            original = copy.deepcopy(load(writing, source, identity))
            now = datetime.now(timezone.utc)
            if source == 'managed':
                if not deleting: raise HTTPException(422, 'Use o formulário Gerenciar para editar este cadastro.')
                if not reviewed['editable_count']: raise HTTPException(409, 'Não há cobranças futuras que possam ser excluídas.')
                updated = writing.commitments.update_one({'_id': original['_id'], 'revision': original.get('revision', {'$exists': False})},
                    {'$set': {'future_deleted_at': now, 'future_cutoff': today().isoformat(), 'updated_at': now}, '$inc': {'revision': 1}})
                if updated is not None and updated.matched_count == 0: raise HTTPException(409, 'O compromisso mudou. Reabra antes de excluir.')
                affected = reviewed['editable_count']
            else:
                available = {row['row_id']: row for row in reviewed['rows']}
                edits = [FutureChange(row_id=row['row_id'], amount=row['amount'], due_date=row['due_date'], cancelled=True) for row in reviewed['rows'] if row['editable']] if deleting else body.rows
                if not edits or len({row.row_id for row in edits}) != len(edits): raise HTTPException(422, 'Selecione parcelas futuras sem repetir linhas.')
                key = f'{source}:{identity}'
                stored = writing.future_schedule_overrides.find_one({'_id': key})
                patches = copy.deepcopy((stored or {}).get('rows', {}))
                parts = original.get('installments', []) if source == 'installment' else [original]
                for change in edits:
                    row = available.get(change.row_id)
                    if not row or not row['editable']: raise HTTPException(409, 'Uma parcela não é futura ou já tem pagamento. Nenhuma alteração foi gravada.')
                    if change.due_date and change.due_date < today(): raise HTTPException(422, 'O vencimento deve ser hoje ou uma data futura.')
                    patches[str(change.row_id)] = {'original_token': digest(parts[change.row_id - 1]), 'amount': str(change.amount),
                        'due_date': change.due_date.isoformat() if change.due_date else row['due_date'], 'cancelled': change.cancelled}
                replacement = {'rows': patches, 'revision': (stored or {}).get('revision', 0) + 1, 'updated_at': now}
                if stored:
                    changed = writing.future_schedule_overrides.update_one({'_id': key, 'revision': stored['revision']}, {'$set': replacement})
                    if changed is not None and changed.matched_count == 0: raise HTTPException(409, 'O cronograma mudou. Reabra antes de salvar.')
                else: writing.future_schedule_overrides.insert_one({'_id': key, **replacement})
                affected = len(edits)
            result = {'persisted': True, 'source': source, 'identity': identity, 'affected_count': affected, 'duplicate_request': False}
            writing.audit_log.insert_one({'event': 'future_commitment_deleted' if deleting else 'future_commitment_edited',
                'source': source, 'identity': identity, 'original': original, 'before_view': reviewed, 'review': body.model_dump(mode='json'), 'created_at': now})
            writing.future_commitment_commands.insert_one({'_id': str(body.request_id), 'request_digest': request_digest, 'result': result, 'created_at': now})
            return result
    except DuplicateKeyError as exc: raise HTTPException(409, 'Outra alteração foi concluída ao mesmo tempo. Reabra e confira novamente.') from exc

@router.put('/{source}/{identity}')
def update(source: Source, identity: str, body: FutureWrite, db=Depends(database)):
    return write(db, source, identity, body)

@router.delete('/{source}/{identity}')
def delete(source: Source, identity: str, body: FutureDelete, db=Depends(database)):
    return write(db, source, identity, body, True)
