"""Editable account metadata, additive to the imported ledger.

Profiles live in a separate collection; the strict imported account schema remains intact.
Their stable keys survive renames, closing and archiving. Deleted empty profiles
retain a tombstone so a built-in account never reappears on the next read.
"""
from datetime import date, datetime, timezone
from uuid import UUID

from fastapi import HTTPException
from pydantic import BaseModel, ConfigDict, Field, model_validator
from typing import Literal

ACCOUNT_CATALOG = (
    ("itau", "Itaú", "conta_corrente", "BRL"),
    ("santander", "Santander", "conta_corrente", "BRL"),
    ("inter", "Inter", "conta_corrente", "BRL"),
    ("btg", "BTG Pactual", "conta_corrente", "BRL"),
    ("mercado_pago", "Mercado Pago", "carteira", "BRL"),
    ("binance", "Binance", "criptoativos", "BRL"),
)
ACCOUNT_KEYS = {row[0] for row in ACCOUNT_CATALOG}


class AccountProfileIn(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    apelido: str = Field(default="", max_length=80)
    instituicao: str = Field(min_length=1, max_length=100)
    tipo: Literal["conta_corrente", "poupanca", "pagamento", "investimento", "carteira", "criptoativos", "outra"]
    agencia: str = Field(default="", max_length=20)
    agencia_digito: str = Field(default="", max_length=5)
    numero: str = Field(default="", max_length=30)
    numero_digito: str = Field(default="", max_length=5)
    status: Literal["aberta", "encerrada"] = "aberta"
    moeda: Literal["BRL"] = "BRL"
    data_abertura: date | None = None
    data_encerramento: date | None = None
    observacoes: str = Field(default="", max_length=1000)
    archived: bool = False

    @model_validator(mode="after")
    def check_dates(self):
        if self.status == "aberta" and self.data_encerramento:
            raise ValueError("Uma conta aberta não pode ter data de encerramento.")
        if self.data_abertura and self.data_encerramento and self.data_encerramento < self.data_abertura:
            raise ValueError("O encerramento deve ser posterior à abertura.")
        if self.numero_digito and not self.numero:
            raise ValueError("Informe o número da conta antes do dígito.")
        if self.agencia_digito and not self.agencia:
            raise ValueError("Informe a agência antes do dígito.")
        return self


class AccountProfileCreate(AccountProfileIn):
    request_id: UUID


class AccountProfileUpdate(AccountProfileIn):
    request_id:UUID|None=None
    expected_revision: int = Field(ge=1)


class AccountProfileDelete(BaseModel):
    model_config = ConfigDict(extra="forbid")
    expected_revision: int = Field(ge=1)
    request_id:UUID|None=None


def profile_document_id(key):
    return "account-profile:" + key


def account_profiles(db):
    defaults = {key: {"key": key, "instituicao": institution, "apelido": "", "tipo": kind,
        "moeda": currency, "status": "aberta", "archived": False, "revision": 1,
        "agencia": "", "agencia_digito": "", "numero": "", "numero_digito": "",
        "data_abertura": None, "data_encerramento": None, "observacoes": ""}
        for key, institution, kind, currency in ACCOUNT_CATALOG}
    for stored in db.account_profiles.find({}):
        if stored.get("entity_type") in {"card", "bill", "month_close"}:
            continue
        key = stored["key"]
        if stored.get("deleted"):
            defaults.pop(key, None)
        else:
            defaults[key] = {**defaults.get(key, {}), **stored["profile"], "key": key,
                "revision": stored["revision"]}
    return list(defaults.values())


def validate_account_key(key, db=None, *, selectable=False):
    profiles = account_profiles(db) if db is not None else [{"key": k} for k in ACCOUNT_KEYS]
    profile = next((item for item in profiles if item["key"] == key), None)
    if profile is None:
        raise HTTPException(422, "Selecione uma conta cadastrada.")
    if selectable and (profile.get("archived") or profile.get("status") == "encerrada"):
        raise HTTPException(422, "Selecione uma conta aberta e não arquivada para uma nova movimentação.")
    return profile


def legacy_accounts_by_profile(db):
    from app.account_positions import account_key_for_legacy
    grouped = {}
    for row in db.accounts.find({"tipo": "conta_corrente"}):
        key = account_key_for_legacy(row)
        if key:
            grouped.setdefault(key, []).append(row)
    # Ambiguity must never assign two accounts in a bank to the same balance.
    return {key: rows[0] for key, rows in grouped.items() if len(rows) == 1}


def profile_for_legacy(db, account):
    from app.account_positions import account_key_for_legacy
    key = account_key_for_legacy(account) if account else None
    matched = legacy_accounts_by_profile(db).get(key)
    return key if matched and matched["_id"] == account["_id"] and any(p["key"] == key for p in account_profiles(db)) else None


def movement_account_context(db, reference):
    from bson import ObjectId
    if reference.startswith("profile:"):
        key = reference.removeprefix("profile:")
        validate_account_key(key, db)
        legacy = legacy_accounts_by_profile(db).get(key)
        return (legacy["_id"] if legacy else None), key
    if ObjectId.is_valid(reference):
        identity = ObjectId(reference)
        account = db.accounts.find_one({"_id": identity})
        return identity, profile_for_legacy(db, account)
    return None, None


def account_usage(db, key):
    from app.account_positions import account_key_for_legacy
    legacy = [row for row in db.accounts.find({"tipo":"conta_corrente"}) if account_key_for_legacy(row)==key]
    checks = {
        "saldos": db.account_balance_snapshots.count_documents({"account_key": key}),
        "capturas": db.provisional_transactions.count_documents({"$or": [
            {"account_profile_id": key}, {"transfer.from_account_key": key}, {"transfer.to_account_key": key}]}),
        "eventos": db.raw_events.count_documents({"$or": [
            {"parsed_payload.account_profile_id": key}, {"parsed_payload.from_account_key": key},
            {"parsed_payload.to_account_key": key}]}),
        "lotes": db.capture_batches.count_documents({"account_ref": "profile:" + key}),
        "movimentos_removidos": db.deleted_movements.count_documents({"$or": [
            {"document.account_profile_id": key}, {"document.transfer.from_account_key": key},
            {"document.transfer.to_account_key": key}]}),
        "experimentos": db.saving_experiments.count_documents({"account_key": key}),
    }
    identity = "account:" + key
    monthly = 0
    for state in db.account_profiles.find({"entity_type": "month_close"}):
        snapshot = state.get("closed_snapshot") or {}
        if (identity in state.get("balances", {})
            or any(item.startswith(identity + ":") for item in state.get("items", {}))
            or any(item.get("group_id") == identity for item in state.get("custom", []))
            or any(group.get("id") == identity for group in snapshot.get("groups", []))):
            monthly += 1
    checks["fechamentos_mensais"] = monthly
    if legacy:
        # The imported identity itself is a historical link; do not remove it.
        checks["cadastro_historico"] = len(legacy)
    return {name: count for name, count in checks.items() if count}


def _stored_values(body):
    values = body.model_dump(exclude={"request_id", "expected_revision"})
    for field in ("data_abertura", "data_encerramento"):
        if values[field]:
            values[field] = values[field].isoformat()
    return values


def create_profile(db, body):
    from app.movement_insert_lock import lock_movement_insert
    lock_movement_insert(db)
    key = "account_" + body.request_id.hex
    identity = profile_document_id(key)
    previous = db.account_profiles.find_one({"_id": identity})
    values = _stored_values(body)
    if previous:
        if previous.get("creation_values") != values or previous.get("deleted"):
            raise HTTPException(409, "Este pedido já foi utilizado. Reabra o cadastro para criar outra conta.")
        return validate_account_key(key, db)
    now = datetime.now(timezone.utc)
    db.account_profiles.insert_one({"_id": identity, "key": key,
        "profile": values, "creation_values": values, "revision": 1, "created_at": now, "updated_at": now})
    db.audit_log.insert_one({"event": "account_profile_created", "account_key": key, "after": values, "created_at": now})
    return validate_account_key(key, db)


def update_profile(db, key, body):
    from app.movement_insert_lock import lock_movement_insert
    lock_movement_insert(db)
    before = validate_account_key(key, db)
    if before["revision"] != body.expected_revision:
        raise HTTPException(409, "A conta mudou. Reabra os detalhes antes de salvar.")
    values = _stored_values(body)
    identity = profile_document_id(key)
    now = datetime.now(timezone.utc)
    stored = db.account_profiles.find_one({"_id": identity})
    if stored:
        result = db.account_profiles.update_one({"_id": identity, "revision": body.expected_revision},
            {"$set": {"profile": values, "updated_at": now}, "$inc": {"revision": 1}})
        if result is not None and result.matched_count != 1:
            raise HTTPException(409, "A conta mudou. Reabra os detalhes antes de salvar.")
    else:
        db.account_profiles.insert_one({"_id": identity, "key": key,
            "profile": values, "revision": 2, "created_at": now, "updated_at": now})
    db.audit_log.insert_one({"event": "account_profile_updated", "account_key": key,
        "before": before, "after": values, "created_at": now})
    return validate_account_key(key, db)


def delete_profile(db, key, body):
    from app.movement_insert_lock import lock_movement_insert
    lock_movement_insert(db)
    before = validate_account_key(key, db)
    if before["revision"] != body.expected_revision:
        raise HTTPException(409, "A conta mudou. Reabra os detalhes antes de excluir.")
    usage = account_usage(db, key)
    if usage:
        raise HTTPException(409, "Esta conta tem histórico ou vínculos. Arquive para preservá-los.")
    identity = profile_document_id(key)
    now = datetime.now(timezone.utc)
    tombstone = {"deleted": True, "revision": before["revision"] + 1, "updated_at": now}
    if db.account_profiles.find_one({"_id": identity}):
        result=db.account_profiles.update_one({"_id": identity, "revision": before["revision"]},
            {"$set": tombstone, "$unset": {"profile": "", "creation_values": ""}})
        if result is not None and result.matched_count != 1:
            raise HTTPException(409, "A conta mudou. Reabra os detalhes antes de excluir.")
    else:
        db.account_profiles.insert_one({"_id": identity, "key": key, **tombstone})
    db.audit_log.insert_one({"event": "account_profile_deleted", "account_key": key, "before": before, "created_at": now})
    return {"deleted": True, "key": key}
